# CSC-555
DePaul CSC 555 Mining Big Data (AWS, Hadoop)
